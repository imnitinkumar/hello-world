package 'httpd' do
  action :install
end

directory 'var/www/html/devopstesting.com' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
  recursive true
end

template '/etc/httpd/conf/httpd.conf' do
  source 'httpd.conf.erb'
end

file '/var/www/html/devopstesting.com/index.html' do
  content '<html>
  <body>
	<h1> hello dev ops engineer, chef testing</h1>
  </body>
</html>'
end

service 'httpd' do
  action [:enable, :start]
end
