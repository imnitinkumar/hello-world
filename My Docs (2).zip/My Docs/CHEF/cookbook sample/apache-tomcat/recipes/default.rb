#
# Cookbook:: apache-tomcat
# Recipe:: default
#
# Copyright:: 2021, The Authors, All Rights Reserved.

include_recipe 'apache-tomcat::misl'
include_recipe 'apache-tomcat::apache'
include_recipe 'apache-tomcat::tomcat'

