#!/bin/bash
echo "Shell Scripting is Fun!"
