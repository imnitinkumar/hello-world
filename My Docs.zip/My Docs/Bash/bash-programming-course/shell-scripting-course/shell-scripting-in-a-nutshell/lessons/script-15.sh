#!/bin/bash

COLORS="red green blue"

for COLOR in $COLORS
do
  echo "COLOR: $COLOR"
done
