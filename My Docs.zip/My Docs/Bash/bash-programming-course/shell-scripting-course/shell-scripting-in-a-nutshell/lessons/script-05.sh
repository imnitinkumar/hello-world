#!/bin/bash
MY_SHELL="bash"
echo "I like the $MY_SHELL shell."
