#!/bin/ksh
echo "This script uses ksh as the interpreter."
