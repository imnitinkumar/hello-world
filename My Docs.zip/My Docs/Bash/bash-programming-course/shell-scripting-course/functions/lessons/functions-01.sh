#!/bin/bash

function hello() {
    echo "Hello!"
}

hello
