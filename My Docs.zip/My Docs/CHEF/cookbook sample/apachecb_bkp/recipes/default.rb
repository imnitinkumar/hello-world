#
# Cookbook:: apachecb
# Recipe:: default
#
# Copyright:: 2021, The Authors, All Rights Reserved.
include_recipe 'apachecb::apache'
