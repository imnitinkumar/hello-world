package 'httpd' do
  action :install
  only_if { node['platform'] == 'redhat' }
end

directory '/var/www/html/devopstesting.com' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

template '/etc/httpd/conf/httpd.conf' do
  source 'httpd.conf.erb'
end

template '/etc/httpd/conf.d/proxyPass.conf' do
  source 'proxyPass.conf.erb'
end

template '/var/www/html/devopstesting.com/index.html' do
  source 'index.html.erb'
end

case node['platform']
when 'redhat'
  # Red Hat settings (ntpd)
  service_name = 'httpd'
  service_action = [:start, :enable]

when 'ubuntu'
  # ubuntu settings
  service_name = 'apache2'
  service_action = [:start]
end

service 'httpd' do
  action [:enable, :start, :reload]
end

bash 'httpd_security' do
  user 'root'
  code <<-EOF
 /usr/sbin/setsebool -P httpd_can_network_connect on
  EOF
end

