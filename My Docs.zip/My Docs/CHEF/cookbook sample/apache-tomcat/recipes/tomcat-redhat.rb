bash 'tomcat-redhat-install' do
      user 'root'
      cwd '/etc'
      code <<-EOH
        rm -f apache-tomcat-8.5.65.tar.gz
        wget https://mirrors.estointernet.in/apache/tomcat/tomcat-8/v8.5.65/bin/apache-tomcat-8.5.65.tar.gz
        tar xvfz apache-tomcat-8.5.65.tar.gz
        mv apache-tomcat-8.5.65 tomcat8
	ls -s apache-tomcat-8.5.65 tomcat
        cd /etc/tomcat/webapps
        rm -rf wartest1.0-SNAPSHOT wartest1.0-SNAPSHOT.war
        sleep 2
        wget https://chef-war-bucket.s3.ap-south-1.amazonaws.com/wartest1.0-SNAPSHOT.war
        cd /etc/tomcat/bin/
        sh startup.sh
        EOH
      end

